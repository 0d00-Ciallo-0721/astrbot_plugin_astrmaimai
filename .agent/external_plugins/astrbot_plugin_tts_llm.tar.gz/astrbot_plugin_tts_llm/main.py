"""
astrbot_plugin_tts_llm — 智能分析版（对接 genie_hiy_server）

触发方式：
  /合成 哥哥，最喜欢你了！
    → LLM 分析中文 → {japanese, emotion}
    → TTS 合成 → 发送语音

公开接口：
  hiy_tts(event, japanese_text, emotion) → 供其他插件调用
"""
import re

from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star, register, StarTools
from astrbot.api import logger, AstrBotConfig
import astrbot.api.message_components as Comp
from astrbot.core.agent.run_context import ContextWrapper
from astrbot.core.agent.tool import FunctionTool, ToolExecResult, ToolSet
from astrbot.core.astr_agent_context import AstrAgentContext
from pydantic import Field
from pydantic.dataclasses import dataclass

from .emotion_manager import EmotionManager
from .tts_engine import TTSEngine

HIY_CHARACTER = "hiy"
HIY_LANGUAGE = "jp"
DEFAULT_EMOTION = "快乐"
ALLOWED_EMOTIONS = {"快乐", "悲伤", "脆弱", "平静"}
ANALYSIS_TOOL_NAME = "output_hiy_speech"
ANALYSIS_TOOL_INSTRUCTION = (
    "\n\n必须调用 output_hiy_speech 工具提交 japanese_text 和 emotion，不要直接输出 JSON 或其他文本。"
    "严格翻译用户原文：不得增加、删减、改写、扩写用户没有说的内容；短句保持短句。"
    "称呼规则：欧尼酱/哥哥/お兄 固定译为「お兄ちゃん」；早上好译为「おはよう」；欢迎回来译为「おかえり」。"
    "用户输入中的 hiyo、hiyohiyo、[HIYO]、ひよひよ、ヒヨヒヨ 都表示同一个口癖单位，"
    "输出日语时必须写作「ひよひよ」；连续多个口癖单位必须按数量保留。"
)


@dataclass
class HiySpeechOutputTool(FunctionTool[AstrAgentContext]):
    name: str = ANALYSIS_TOOL_NAME
    description: str = "输出适合妃爱朗读的自然日语和对应情绪。"
    parameters: dict = Field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "japanese_text": {
                    "type": "string",
                    "description": "忠实表达原中文、适合口语朗读的自然日语。",
                },
                "emotion": {
                    "type": "string",
                    "enum": sorted(ALLOWED_EMOTIONS),
                    "description": "语音情绪。",
                },
            },
            "required": ["japanese_text", "emotion"],
            "additionalProperties": False,
        },
    )

    async def call(
        self, context: ContextWrapper[AstrAgentContext], **kwargs
    ) -> ToolExecResult:
        return "structured speech output accepted"


ANALYSIS_TOOLS = ToolSet([HiySpeechOutputTool()])

_HIYO_RUN_RE = re.compile(r"(?<![A-Za-z0-9_])(?:hiyo)+(?![A-Za-z0-9_])", re.IGNORECASE)
_HIYO_MARKER_RE = re.compile(r"\[HIYO\]|ひよひよ|ヒヨヒヨ", re.IGNORECASE)


def _normalize_hiyo_run(match: re.Match) -> str:
    units = len(match.group(0)) // len("hiyo")
    count = (units + 1) // 2
    return "ひよひよ" * count


def normalize_hiyohiyo(text: str) -> str:
    if not text:
        return text
    text = _HIYO_MARKER_RE.sub("ひよひよ", text)
    return _HIYO_RUN_RE.sub(_normalize_hiyo_run, text)


_TTS_COMMAND_RE = re.compile(r"^\s*/?(?:合成|语音)(?:\s+|$)")


def extract_tts_command_text(event: AstrMessageEvent, parsed_text: str = "") -> str:
    """从原始消息中截取命令后的完整文本，避免空格分词丢失后半句。"""
    raw = str(getattr(event, "message_str", "") or "")
    raw = raw.replace("\u200b", "").strip()
    match = _TTS_COMMAND_RE.match(raw)
    if match:
        return raw[match.end():].strip()
    return (parsed_text or "").strip()


@register(
    "astrbot_plugin_tts_llm",
    "clown145",
    "妃爱语音合成 — LLM 智能分析",
    "2.0.0",
    "https://github.com/clown145/astrbot_plugin_tts_llm",
)
class LlmTtsPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config

        plugin_data_dir = StarTools.get_data_dir("astrbot_plugin_tts_llm")
        self.emotion_manager = EmotionManager(plugin_data_dir / "emotions.json")

        import httpx
        self.http_client = httpx.AsyncClient(timeout=300.0)
        self.tts_engine = TTSEngine(self.config, self.http_client, plugin_data_dir)

        logger.info("妃爱 TTS 插件 v2.0 已加载")

    # === 核心：中文 → LLM分析 → 日语+情感 ===

    async def _analyze_text(self, chinese_text: str) -> dict:
        """调用 LLM Tool 将中文转为标准日语与情绪参数。"""
        provider_id = self.config.get("llm_provider_id", "")
        if not provider_id:
            logger.error("未配置 llm_provider_id")
            return {}

        try:
            system_prompt = (
                str(self.config.get("llm_prompt", "") or "")
                + ANALYSIS_TOOL_INSTRUCTION
            )
            resp = await self.context.llm_generate(
                chat_provider_id=provider_id,
                prompt=normalize_hiyohiyo(chinese_text),
                system_prompt=system_prompt,
                tools=ANALYSIS_TOOLS,
            )
            if ANALYSIS_TOOL_NAME not in resp.tools_call_name:
                logger.warning("LLM 未调用结构化输出工具")
                return {}

            index = resp.tools_call_name.index(ANALYSIS_TOOL_NAME)
            result = resp.tools_call_args[index]
            japanese_text = result.get("japanese_text")
            emotion = result.get("emotion")
            if not isinstance(japanese_text, str) or not japanese_text.strip():
                logger.warning("LLM Tool 返回的 japanese_text 无效")
                return {}
            if emotion not in ALLOWED_EMOTIONS:
                logger.warning(f"LLM Tool 返回了无效情绪: {emotion}")
                return {}
            return {
                "japanese_text": normalize_hiyohiyo(japanese_text.strip()),
                "emotion": emotion,
            }
        except Exception as e:
            logger.error(f"LLM 分析失败: {e}")
            return {}

    # === 公开接口 ===

    async def hiy_tts(
        self,
        event: AstrMessageEvent,
        japanese_text: str,
        emotion: str = "快乐",
        visible_text: str = "",
    ):
        """合成妃爱语音。返回消息链或 None。"""
        if not japanese_text:
            return None

        if emotion not in ALLOWED_EMOTIONS:
            emotion = DEFAULT_EMOTION

        japanese_text = normalize_hiyohiyo(japanese_text.strip())
        if not japanese_text:
            return None

        emo = self.emotion_manager.get_emotion_data(HIY_CHARACTER, emotion)
        if not emo:
            emo = self.emotion_manager.get_emotion_data(HIY_CHARACTER, DEFAULT_EMOTION)
        if not emo:
            return None

        path = await self.tts_engine.synthesize(
            character_name=HIY_CHARACTER,
            ref_audio_path=emo["ref_audio_path"],
            ref_audio_text=emo["ref_audio_text"],
            text=japanese_text,
            session_id_for_log=event.unified_msg_origin,
            language=HIY_LANGUAGE,
        )

        if not path:
            return None

        chain = [Comp.Record(file=path)]
        if visible_text and self.config.get("send_text_with_audio", True):
            chain.insert(0, Comp.Plain(visible_text))

        return chain

    # === 指令 ===

    @filter.command("合成", alias={"语音"})
    async def cmd_tts(self, event: AstrMessageEvent, text: str = ""):
        """
        /合成 中文文本
        /语音 中文文本
          → LLM 分析 → {japanese, emotion}
          → TTS 合成 → 发送语音

        例:
          /合成 哥哥，最喜欢你了！
          /语音 哥哥，最喜欢你了！
          /合成 今天好累啊，想休息一下
        """
        text = extract_tts_command_text(event, text)

        if not text:
            yield event.plain_result(
                "用法: /合成 <中文文本> 或 /语音 <中文文本>\n"
                "例: /合成 哥哥，最喜欢你了！"
            )
            return

        yield event.plain_result("🤔 分析中...")

        result = await self._analyze_text(text)
        japanese = result.get("japanese_text", "")
        emotion = result.get("emotion", "")

        if not japanese:
            yield event.plain_result("❌ 分析失败：无法生成日语文本")
            return

        logger.info(f"/合成: 「{text[:30]}...」→ [{emotion}] 「{japanese}」")
        yield event.plain_result(f"💬 {japanese}")

        try:
            chain = await self.hiy_tts(event, japanese, emotion, visible_text=text)
        except Exception as e:
            logger.error(f"hiy_tts 异常: {e}")
            chain = None
        logger.info(f"hiy_tts 返回: chain={chain is not None}")
        if chain:
            yield event.chain_result(chain)
            logger.info("语音链已 yield")
        else:
            yield event.plain_result("❌ 合成失败")
        event.stop_event()

    # === 情感管理 ===

    @filter.command("注册感情")
    async def register_emotion(self, event: AstrMessageEvent, character_name: str,
                               emotion_name: str, ref_audio_path: str,
                               ref_audio_text: str, language: str = None):
        if ".." in ref_audio_path or ref_audio_path.startswith("/"):
            yield event.plain_result("❌ 音频路径无效")
            return
        ok = self.emotion_manager.register_emotion(
            character_name, emotion_name, ref_audio_path, ref_audio_text, language)
        yield event.plain_result(f"✅ {character_name}.{emotion_name} 已注册" if ok else "❌ 保存失败")

    @filter.command("删除感情")
    async def delete_emotion(self, event: AstrMessageEvent,
                             character_name: str, emotion_name: str):
        if not self.emotion_manager.character_exists(character_name):
            yield event.plain_result(f"❌ 角色 {character_name} 不存在")
            return
        yield event.plain_result("✅ 已删除" if self.emotion_manager.delete_emotion(character_name, emotion_name) else "❌ 删除失败")

    @filter.command("查看感情")
    async def view_emotions(self, event: AstrMessageEvent):
        data = self.emotion_manager.emotions_data
        if not data:
            yield event.plain_result("暂无注册感情")
            return
        lines = ["已注册感情："]
        for char, emos in data.items():
            lines.append(f"\n角色: {char}")
            for e in emos:
                lines.append(f"  - {e}")
        yield event.plain_result("\n".join(lines))

    # === 生命周期 ===

    async def terminate(self):
        await self.tts_engine.terminate()
        await self.http_client.aclose()
        logger.info("妃爱 TTS 插件已卸载")
