"""
TTS 引擎 — 精简版（对接 genie_hiy_server）
- genie_hiy_server 返回完整 WAV，直接保存
- split_mode 走服务端三层路由
- 保留 FIFO 队列 + 多服务器故障转移
"""
import asyncio
import os
import re
import uuid
from pathlib import Path
from typing import Optional, Dict

import httpx
from astrbot.api import logger, AstrBotConfig


class TTSEngine:
    """TTS 合成核心：HTTP 调用 + FIFO 调度 + 故障转移"""

    def __init__(
        self,
        config: AstrBotConfig,
        http_client: httpx.AsyncClient,
        plugin_data_dir: Path,
    ):
        self.config = config
        self.http_client = http_client
        self.tts_server_index = 0
        self._server_locks: Dict[str, asyncio.Lock] = {}
        self._synthesis_lock = asyncio.Lock()

        self.temp_audio_dir = plugin_data_dir / "temp_audio"
        self.temp_audio_dir.mkdir(parents=True, exist_ok=True)

        # 全局 FIFO 调度
        self._request_queue = asyncio.Queue()
        self._request_worker_task = asyncio.create_task(self._request_worker_loop())
        # 定期清理
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    # === 文本清洗 ===

    def _clean_text_for_tts(self, text: str) -> str:
        pattern = self.config.get("tts_text_clean_regex", "")
        if not pattern:
            return text.strip()
        try:
            for _ in range(10):
                updated = re.sub(pattern, "", text)
                if updated == text:
                    break
                text = updated
        except re.error:
            pass
        return re.sub(r"\s+", " ", text).strip()

    # === 文件清理 ===

    async def _cleanup_loop(self):
        import time
        while True:
            try:
                await asyncio.sleep(1800)
                now = time.time()
                if not self.temp_audio_dir.exists():
                    continue
                for fp in self.temp_audio_dir.glob("*.wav"):
                    try:
                        if now - fp.stat().st_mtime > 1800:
                            fp.unlink()
                    except Exception:
                        pass
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    # === FIFO 调度 ===

    async def _request_worker_loop(self):
        while True:
            try:
                request, future = await self._request_queue.get()
            except asyncio.CancelledError:
                break
            if future.cancelled():
                self._request_queue.task_done()
                continue
            try:
                result = await self._synthesize_direct(**request)
                if not future.done():
                    future.set_result(result)
            except asyncio.CancelledError:
                if not future.done():
                    future.set_result(None)
                raise
            except Exception as e:
                logger.error(f"[worker] 合成异常: {e}")
                if not future.done():
                    future.set_result(None)
            finally:
                self._request_queue.task_done()

    async def terminate(self):
        if self._request_worker_task:
            self._request_worker_task.cancel()
            await asyncio.gather(self._request_worker_task, return_exceptions=True)
            while not self._request_queue.empty():
                try:
                    _, f = self._request_queue.get_nowait()
                    if not f.done():
                        f.set_result(None)
                    self._request_queue.task_done()
                except asyncio.QueueEmpty:
                    break
        if self._cleanup_task:
            self._cleanup_task.cancel()
            await asyncio.gather(self._cleanup_task, return_exceptions=True)

    # === 单服务器合成 ===

    def _get_server_lock(self, url: str) -> asyncio.Lock:
        if url not in self._server_locks:
            self._server_locks[url] = asyncio.Lock()
        return self._server_locks[url]

    async def _attempt_synthesis_on_server(
        self,
        server_url: str,
        character_name: str,
        ref_audio_path: str,
        ref_audio_text: str,
        text: str,
        session_id_for_log: str,
        language: str = "jp",
    ) -> Optional[str]:
        lock = self._get_server_lock(server_url)
        async with lock:
            try:
                # 1. 设置参考音频
                await self.http_client.post(
                    f"{server_url}/set_reference_audio",
                    json={
                        "character_name": character_name,
                        "audio_path": ref_audio_path,
                        "audio_text": ref_audio_text,
                        "language": language,
                    },
                    timeout=60,
                )
                # 2. 合成（genie_hiy_server 返回完整 WAV）
                tts_timeout = self.config.get("tts_timeout_seconds", 120)
                r = await self.http_client.post(
                    f"{server_url}/tts",
                    json={
                        "character_name": character_name,
                        "text": text,
                        "split_mode": "auto",
                    },
                    timeout=tts_timeout,
                )
                r.raise_for_status()
                # 服务端返回完整 WAV，直接保存
                output_path = self.temp_audio_dir / f"{uuid.uuid4()}.wav"
                with open(str(output_path), "wb") as f:
                    f.write(r.content)
                return str(output_path)
            except Exception as e:
                logger.warning(f"[{session_id_for_log}] {server_url} 失败: {e}")
                return None

    # === 合成主逻辑 ===

    async def _synthesize_direct(
        self,
        character_name: str,
        ref_audio_path: str,
        ref_audio_text: str,
        text: str,
        session_id_for_log: str,
        language: str = "jp",
    ) -> Optional[str]:
        """合成整段文本，支持多服务器故障转移"""
        async with self._synthesis_lock:
            servers = self.config.get("tts_servers", [])
            if not servers:
                logger.error(f"[{session_id_for_log}] 未配置 TTS 服务器")
                return None

            # 文本清洗
            text = self._clean_text_for_tts(text) if self.config.get("enable_tts_text_cleaning") else text
            if not text:
                logger.warning(f"[{session_id_for_log}] 清洗后文本为空")
                return None

            max_retries = max(int(self.config.get("tts_max_retries", 3)), 1)
            start = self.tts_server_index
            for attempt in range(max_retries):
                for i in range(len(servers)):
                    idx = (start + i) % len(servers)
                    server_url = servers[idx].strip("/")
                    if attempt == 0 and i == 0:
                        self.tts_server_index = (start + 1) % len(servers)

                    path = await self._attempt_synthesis_on_server(
                        server_url=server_url,
                        character_name=character_name,
                        ref_audio_path=ref_audio_path,
                        ref_audio_text=ref_audio_text,
                        text=text,
                        session_id_for_log=session_id_for_log,
                        language=language,
                    )
                    if path:
                        return path

            logger.error(f"[{session_id_for_log}] 所有服务器合成失败")
            return None

    # === 公共接口 ===

    async def synthesize(
        self,
        character_name: str,
        ref_audio_path: str,
        ref_audio_text: str,
        text: str,
        session_id_for_log: str,
        language: str = "jp",
    ) -> Optional[str]:
        """入队合成请求，返回 WAV 文件路径"""
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        await self._request_queue.put(({
            "character_name": character_name,
            "ref_audio_path": ref_audio_path,
            "ref_audio_text": ref_audio_text,
            "text": text,
            "session_id_for_log": session_id_for_log,
            "language": language,
        }, future))
        return await future
